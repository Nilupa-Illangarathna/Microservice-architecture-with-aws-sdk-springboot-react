Open your terminal and run the following commands:
	npx create-react-app frontend
	cd frontend
	npm install react-router-dom
		 -React Router is a library that allows you to handle routing and navigation in a React application
	npm start
